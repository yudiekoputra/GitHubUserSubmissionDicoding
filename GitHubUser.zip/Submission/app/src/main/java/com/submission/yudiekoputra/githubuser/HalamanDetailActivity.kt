package com.submission.yudiekoputra.githubuser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class HalamanDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_detail)

        val user = intent.getParcelableExtra<User>(MainActivity.INTENT_PARCELABLE)
        val img_detail = findViewById<ImageView>(R.id.img_detail)
        val txt_username = findViewById<TextView>(R.id.text_Username)
        val txt_nama = findViewById<TextView>(R.id.text_nama)
        val txt_location = findViewById<TextView>(R.id.text_location)
        val txt_company = findViewById<TextView>(R.id.text_company)
        val txt_repository = findViewById<TextView>(R.id.text_repository)
        val txt_followers = findViewById<TextView>(R.id.text_followers)
        val txt_following = findViewById<TextView>(R.id.text_following)

        Glide.with(this)
            .load(user?.avatar)
            .circleCrop()
            .into(img_detail)
        //user?.avatar?.let { img_detail.setImageResource(it) }
        txt_username.text = user?.username
        txt_nama.text = user?.name
        txt_location.text = user?.location
        txt_company.text = user?.company
        txt_repository.text = user?.repository
        txt_followers.text = user?.followers
        txt_following.text = user?.following

    }
}